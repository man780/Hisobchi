#SKD101|hisob|5|2013.03.31 14:52:12|109|9|72|18|9|1

DROP TABLE IF EXISTS `cat`;
CREATE TABLE `cat` (
  `id` int(3) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL DEFAULT '',
  `priz` int(2) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=11 /*!40101 DEFAULT CHARSET=cp1251 */;

INSERT INTO `cat` VALUES
(1, 'Transport', 2),
(2, 'Oziq Ovqat', 2),
(3, 'Maishiy xizmat', 2),
(4, 'Maosh', 1),
(5, 'Repititor', 1),
(7, 'Gap', 2),
(8, 'Sovg`a', 2),
(9, 'Hi-tech', 2),
(10, 'Choyxona', 2);

DROP TABLE IF EXISTS `chiqim`;
CREATE TABLE `chiqim` (
  `id` int(9) NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL DEFAULT '0000-00-00',
  `cat_c` varchar(255) NOT NULL DEFAULT '',
  `podcat_c` varchar(255) NOT NULL DEFAULT '',
  `soni` int(6) NOT NULL DEFAULT '0',
  `sum_c` int(9) NOT NULL DEFAULT '0',
  `primech` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=96 /*!40101 DEFAULT CHARSET=cp1251 */;

INSERT INTO `chiqim` VALUES
(2, '2012-04-02', 'Transport', 'Marshurutka', 2, 1600, '1-apreladan narxlar oshdi'),
(3, '2012-04-02', 'Transport', 'Taksi', 1, 2000, ''),
(4, '2012-04-03', '1', '', 3, 3200, 'Somsa'),
(5, '2012-04-03', '0', '', 5, 3500, ''),
(6, '2012-04-04', 'Transport', 'Marshurutka', 2, 1600, ''),
(7, '2012-04-05', 'Transport', '', 3, 2200, ''),
(8, '2012-04-06', 'Transport', 'Marshurutka', 2, 1600, ''),
(9, '2012-04-09', 'Transport', '', 50, 35000, 'jeton'),
(10, '2012-04-09', 'Transport', 'Marshurutka', 2, 1600, ''),
(11, '2012-04-10', 'Transport', '', 3, 2300, ''),
(12, '2012-04-11', 'Transport', 'Marshurutka', 2, 1600, ''),
(13, '2012-04-12', 'Transport', 'Marshurutka', 3, 2300, ''),
(14, '2012-04-12', 'Transport', 'Taksi', 1, 1000, ''),
(15, '2012-04-13', 'Transport', 'Marshurutka', 2, 1600, ''),
(16, '2012-04-16', 'Transport', 'Marshurutka', 2, 1600, ''),
(17, '2012-04-17', 'Transport', '', 3, 2300, ''),
(19, '2012-04-18', 'Transport', 'Taksi', 1, 1000, ''),
(22, '2012-04-19', 'Transport', 'Marshurutka', 3, 2300, ''),
(21, '2012-04-18', 'Transport', 'Marshurutka', 2, 1600, ''),
(23, '2012-04-23', 'Transport', 'Marshurutka', 2, 1600, ''),
(24, '2012-04-23', 'Hi-tech', '', 2, 1600, ''),
(25, '2012-04-24', 'Transport', 'Avtobus', 3, 2300, ''),
(26, '2012-04-25', 'Transport', 'Marshurutka', 2, 1600, ''),
(28, '2012-04-27', 'Transport', 'Avtobus', 3, 2300, ''),
(29, '2012-04-27', 'Transport', 'Avtobus', 2, 1600, ''),
(30, '2012-04-30', 'Transport', 'Avtobus', 2, 1600, ''),
(31, '2012-05-01', 'Transport', 'Avtobus', 3, 2300, ''),
(32, '2012-05-02', 'Oziq Ovqat', 'Tushlik', 3, 3000, ''),
(33, '2012-05-02', 'Transport', 'Avtobus', 2, 1600, ''),
(34, '2012-05-04', 'Transport', 'Avtobus', 3, 2300, ''),
(35, '2012-05-05', 'Transport', 'Avtobus', 2, 1600, ''),
(36, '2012-05-07', 'Transport', 'Avtobus', 2, 1600, ''),
(37, '2012-05-08', 'Sovg`a', '', 1, 10000, 'Husan'),
(38, '2012-05-08', 'Transport', 'Avtobus', 1, 700, ''),
(39, '2012-05-08', 'Transport', 'Avtobus', 3, 2300, ''),
(47, '2012-05-14', 'Transport', 'Metro', 50, 35000, ''),
(44, '2012-05-08', 'Oziq Ovqat', 'Tushlik', 2, 2000, 'Somsa'),
(46, '2012-05-11', 'Transport', 'Taksi', 3, 2300, ''),
(48, '2012-05-15', 'Transport', 'Avtobus', 2, 1600, ''),
(49, '2012-05-15', 'Transport', 'Avtobus', 3, 2300, ''),
(50, '2012-05-18', 'Transport', 'Avtobus', 2, 1600, ''),
(51, '2012-05-17', 'Transport', 'Avtobus', 3, 2300, ''),
(52, '2012-05-22', 'Transport', 'Avtobus', 2, 1600, ''),
(53, '2012-05-22', 'Transport', 'Avtobus', 3, 2300, ''),
(54, '2012-05-15', 'Sovg`a', '', 1, 10000, 'Ksenya'),
(55, '2012-05-24', 'Transport', 'Avtobus', 3, 2300, ''),
(56, '2012-05-23', 'Transport', 'Avtobus', 2, 1600, ''),
(57, '2012-05-25', 'Transport', 'Avtobus', 2, 1600, ''),
(58, '2012-05-28', 'Transport', 'Taksi', 2, 1600, ''),
(59, '2012-05-29', 'Transport', 'Avtobus', 3, 2300, ''),
(60, '2012-05-29', 'Sovg`a', '', 1, 10000, 'Aziz aka'),
(61, '2012-05-30', 'Transport', 'Avtobus', 2, 1600, ''),
(62, '2012-05-30', 'Transport', 'Avtobus', 2, 1600, ''),
(63, '2012-05-31', 'Transport', 'Avtobus', 3, 2300, ''),
(64, '2012-06-01', 'Transport', 'Avtobus', 2, 1600, ''),
(65, '0000-00-00', '', '', 0, 0, ''),
(66, '2012-06-04', 'Transport', 'Avtobus', 2, 1600, ''),
(75, '2012-06-04', 'Transport', 'Avtobus', 2, 1500, ''),
(68, '2012-06-06', 'Transport', 'Avtobus', 2, 1600, ''),
(74, '2012-06-07', 'Oziq Ovqat', 'Tushlik', 1, 800, ''),
(73, '2012-06-05', 'Transport', 'Avtobus', 2, 1600, ''),
(95, '2012-06-14', 'Transport', 'Metro', 50, 35000, ''),
(77, '2012-06-05', 'Gap', '', 1, 75000, ''),
(78, '2012-05-05', 'Gap', '', 1, 75000, ''),
(79, '2012-04-05', 'Gap', '', 1, 75000, ''),
(80, '2012-04-05', 'Gap', '', 1, 75000, 'Nodir'),
(82, '2012-06-11', 'Transport', 'Avtobus', 2, 1600, ''),
(84, '2012-06-07', 'Choyxona', '', 1, 15000, ''),
(90, '2012-06-14', 'Transport', 'Avtobus', 3, 2300, ''),
(89, '2012-06-12', 'Transport', 'Avtobus', 3, 2200, ''),
(88, '2012-06-13', 'Transport', 'Avtobus', 2, 1500, ''),
(91, '2012-06-07', 'Transport', 'Avtobus', 3, 2300, '');

DROP TABLE IF EXISTS `kirim`;
CREATE TABLE `kirim` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL DEFAULT '0000-00-00',
  `cat_k` varchar(255) NOT NULL DEFAULT '',
  `podcat_k` varchar(255) NOT NULL DEFAULT '',
  `soni` int(6) NOT NULL DEFAULT '0',
  `sum` int(9) NOT NULL DEFAULT '0',
  `primech` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=68 /*!40101 DEFAULT CHARSET=cp1251 */;

INSERT INTO `kirim` VALUES
(45, '2012-04-24', 'Repititor', 'Seshanba', 2, 100000, ''),
(4, '2012-04-04', 'Maosh', '', 1, 86522, ''),
(5, '2012-04-06', 'Maosh', '', 1, 282500, ''),
(54, '2012-05-29', 'Repititor', 'Seshanba', 2, 100000, ''),
(53, '2012-05-24', 'Repititor', 'Seshanba', 1, 50000, 'Abduqodir'),
(52, '2012-05-24', 'Repititor', 'Dushanba', 1, 50000, 'Musobek'),
(51, '2012-05-11', 'Maosh', 'Plastik', 1, 86000, ''),
(48, '2012-05-02', 'Repititor', 'Seshanba', 2, 100000, ''),
(49, '2012-05-05', 'Maosh', 'Norasmiy', 1, 309500, ''),
(50, '2012-05-11', 'Maosh', 'Rasmiy', 1, 58000, ''),
(46, '2012-04-02', 'Repititor', 'Dushanba', 1, 25000, ''),
(44, '2012-04-16', 'Repititor', 'dushanba', 1, 60000, ''),
(43, '2012-04-10', 'Maosh', '', 1, 58000, ''),
(55, '2012-05-30', 'Repititor', 'Seshanba', 1, 50000, ''),
(56, '2012-06-02', 'Repititor', 'Dushanba', 1, 37500, ''),
(57, '2012-06-07', 'Maosh', 'Norasmiy', 1, 309500, ''),
(58, '2012-06-12', 'Maosh', 'Plastik', 1, 74000, ''),
(59, '2012-06-13', 'Maosh', 'Rasmiy', 1, 70000, '');

DROP TABLE IF EXISTS `pod_cat`;
CREATE TABLE `pod_cat` (
  `id` int(4) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL DEFAULT '',
  `priz` int(2) NOT NULL DEFAULT '0',
  `priz_cat` int(2) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=10 /*!40101 DEFAULT CHARSET=cp1251 */;

INSERT INTO `pod_cat` VALUES
(1, 'Taksi', 2, 1),
(2, 'Avtobus', 2, 1),
(3, 'Metro', 2, 1),
(4, 'Tushlik', 2, 2),
(5, 'Rasmiy', 1, 4),
(6, 'Plastik', 1, 4),
(7, 'Norasmiy', 1, 4),
(8, 'Dushanba', 1, 5),
(9, 'Seshanba', 1, 5);

DROP TABLE IF EXISTS `settings`;
CREATE TABLE `settings` (
  `id` int(2) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL DEFAULT '',
  `text` text NOT NULL,
  `page` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 /*!40101 DEFAULT CHARSET=cp1251 */;

INSERT INTO `settings` VALUES
(1, 'Bosh sahifa', 'Bosh sahifa', 'index');

